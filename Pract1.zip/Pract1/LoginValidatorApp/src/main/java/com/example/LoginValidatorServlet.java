package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.IOException;
import java.io.PrintWriter;


public class LoginValidatorServlet extends HttpServlet {
	 private static final long serialVersionUID = 1L;

	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        response.setContentType("text/html;charset=UTF-8");
	        PrintWriter out = response.getWriter();

	        // Get the input parameters 'username' and 'password' from the client
	        String username = request.getParameter("username");
	        String password = request.getParameter("password");

	        // Validate the username and password
	        boolean isValid = isValidLogin(username, password);

	        // Send the result back to the client
	        out.println("<html>");
	        out.println("<head><title>Login Validation</title></head>");
	        out.println("<body>");
	        out.println("<h2>The login with username '" + username + "' and password '" + password + "' is " +
	                    (isValid ? "valid" : "invalid") + ".</h2>");
	        out.println("</body>");
	        out.println("</html>");
	    }

	    private boolean isValidLogin(String username, String password) {
	        // You can implement your logic here to validate the username and password
	        // For simplicity, let's use a basic check (username = "user" and password = "password")
	        return "user".equals(username) && "password".equals(password);
	    }
}
