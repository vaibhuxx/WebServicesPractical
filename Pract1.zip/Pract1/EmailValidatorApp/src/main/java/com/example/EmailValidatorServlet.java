package com.example;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class EmailValidatorServlet
 */
public class EmailValidatorServlet extends HttpServlet {
	 private static final long serialVersionUID = 1L;

	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        response.setContentType("text/html;charset=UTF-8");
	        PrintWriter out = response.getWriter();

	        // Get the input parameter 'email' from the client
	        String email = request.getParameter("email");

	        // Validate the email using regular expression
	        boolean isValid = isValidEmail(email);

	        // Send the result back to the client
	        out.println("<html>");
	        out.println("<head><title>Email Validation</title></head>");
	        out.println("<body>");
	        out.println("<h2>The email address '" + email + "' is " + (isValid ? "valid" : "invalid") + ".</h2>");
	        out.println("</body>");
	        out.println("</html>");
	    }

	    private boolean isValidEmail(String email) {
	        // Regular expression for a valid email address
	        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
	        Pattern pattern = Pattern.compile(emailRegex);
	        Matcher matcher = pattern.matcher(email);
	        return matcher.matches();
	    }
}
