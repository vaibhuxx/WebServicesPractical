package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class StaffDetailsServlet extends HttpServlet {
	  private static final long serialVersionUID = 1L;

	    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/staffdb";
	    private static final String JDBC_USER = "root";
	    private static final String JDBC_PASSWORD = "root";

	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        response.setContentType("text/html;charset=UTF-8");
	        PrintWriter out = response.getWriter();

	        // Get the input parameter 'sname' from the client
	        String staffName = request.getParameter("sname");

	        // Connect to the database and retrieve staff details
	        try {
	        	Class.forName("com.mysql.cj.jdbc.Driver");

	            Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);

	            String query = "SELECT * FROM staff WHERE sname=?";
	            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	                preparedStatement.setString(1, staffName);
	                ResultSet resultSet = preparedStatement.executeQuery();

	                out.println("<html>");
	                out.println("<head><title>Staff Details</title></head>");
	                out.println("<body>");
	                if (resultSet.next()) {
	                    out.println("<h2>Staff Details:</h2>");
	                    out.println("<p><strong>Staff Number:</strong> " + resultSet.getInt("sno") + "</p>");
	                    out.println("<p><strong>Staff Name:</strong> " + resultSet.getString("sname") + "</p>");
	                    out.println("<p><strong>Designation:</strong> " + resultSet.getString("designation") + "</p>");
	                    out.println("<p><strong>Salary:</strong> $" + resultSet.getDouble("salary") + "</p>");
	                } else {
	                    out.println("<h2>No staff found with the name '" + staffName + "'.</h2>");
	                }
	                out.println("</body>");
	                out.println("</html>");
	            }
	            connection.close();
	        }  catch (ClassNotFoundException e) {
	            e.printStackTrace();
	            out.println("Error loading MySQL JDBC driver: " + e.getMessage());
	        } catch (SQLException e) {
	            e.printStackTrace();
	            out.println("Error connecting to the database: " + e.getMessage());
	        }
	    }

}
