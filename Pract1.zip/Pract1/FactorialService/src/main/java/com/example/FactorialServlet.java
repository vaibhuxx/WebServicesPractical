package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/FactorialServlet")
public class FactorialServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get the input parameter 'number' from the client
        String numberParam = request.getParameter("number");

        try {
            // Convert the parameter to an integer
            int number = Integer.parseInt(numberParam);

            // Calculate the factorial
            long factorial = calculateFactorial(number);

            // Send the result back to the client
            out.println("<html>");
            out.println("<head><title>Factorial Result</title></head>");
            out.println("<body>");
            out.println("<h2>The factorial of " + number + " is: " + factorial + "</h2>");
            out.println("</body>");
            out.println("</html>");
        } catch (NumberFormatException e) {
            // Handle invalid input
            out.println("<html>");
            out.println("<head><title>Error</title></head>");
            out.println("<body>");
            out.println("<h2>Invalid input. Please provide a positive integer.</h2>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    private long calculateFactorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * calculateFactorial(n - 1);
        }
    }
}
