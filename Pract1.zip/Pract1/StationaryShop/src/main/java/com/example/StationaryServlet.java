package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.IOException;
import java.io.PrintWriter;

public class StationaryServlet extends HttpServlet {
	 private static final long serialVersionUID = 1L;

	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        response.setContentType("text/html;charset=UTF-8");
	        PrintWriter out = response.getWriter();

	        // Get the input parameter 'item' from the client
	        String item = request.getParameter("item");

	        // Get the price based on the stationary item
	        double price = getPrice(item);

	        // Send the result back to the client
	        out.println("<html>");
	        out.println("<head><title>Stationary Price</title></head>");
	        out.println("<body>");
	        out.println("<h2>The price of " + item + " is: Rupees" + price + "</h2>");
	        out.println("</body>");
	        out.println("</html>");
	    }

	    private double getPrice(String item) {
	        // You can implement your logic here to get the price based on the stationary item
	        // For simplicity, let's use a simple mapping
	        switch (item.toLowerCase()) {
	            case "pen":
	                return 15;
	            case "notebook":
	                return 30;
	            case "pencil":
	                return 5;
	            default:
	                return 0.00; // Default price for unknown items
	        }
	    }
}
